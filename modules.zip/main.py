from PyQt5.QtWidgets import QPushButton, QWidget, QApplication, QMainWindow, QHBoxLayout,QVBoxLayout, QGridLayout, QDialog
from PyQt5.QtCore import Qt, QSize
from PyQt5.QtGui import QIcon
import sys, pkgutil
from functools import partial
from PyQt5.QtGui import QPainter, QBrush, QPen
import PyQt5.QtCore

from PyQt5.QtCore import Qt
from PyQt5 import QtGui

from PyQt5.QtWidgets import QApplication, QMainWindow

from PyQt5.QtWidgets import QFileDialog

# exec(open("/home/aviv/avivsroot/lib/aviv_root.py").read())
from PyQt5.QtWidgets import (QMessageBox)
from PyQt5.QtWidgets import QMainWindow, QAction
from PyQt5.QtWidgets import (QApplication, QCheckBox,
                             QGridLayout, QGroupBox, QHBoxLayout, QLabel, QLineEdit,
                             QPushButton, QSizePolicy,
                             QSpinBox, QTableWidget,
                             QVBoxLayout, QWidget)
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.backends.backend_qt5agg import NavigationToolbar2QT as NavigationToolbar


# from ModuleBtn import ModuleBtn
from sandbox import SandBox
from ResultView import ResultView
# from moduleGUI import ModuleGui
# from modal import InvoiceModal
from ModuleBtn import ModuleBtn
from ModuleForm import ModuleForm
class AfelApp(QMainWindow):
    def __init__(self, parent=None):
        super(AfelApp, self).__init__(parent)
        # self.setStyleSheet("""re
        #     .QWidget{
        #         border: 5px solid black;
        #
        #         background-color: gray;
        #         /* background-image: url('./bg.jpg');*/
        #     }
        # """)
        self.setGeometry(10, 10, 1000, 1200)
        self.init_UI()

    def init_UI(self):
        mainWindow = QWidget(self)
        self.setCentralWidget(mainWindow)
        mainlay = QHBoxLayout()
        mainWindow.setLayout(mainlay)

        #  load area
        loadbox = QGroupBox()

        loadLay = QVBoxLayout()

        loadLay.addStretch(1)

        loadbox.setLayout(loadLay)

        modules = map(lambda n: n[1], pkgutil.iter_modules(['modules']))
        for name in modules:

            exec("from modules.{0} import {0}".format(name))
            mdlbtn = ModuleBtn(name, eval(name))
            loadLay.addWidget(mdlbtn)
        startbtn = QPushButton('start process')
        startbtn.clicked.connect(self.start_process)
        loadLay.addWidget(startbtn)



        #  sandbox area
        self.sandbox = SandBox()
        self.sandboxlay = QVBoxLayout()
        self.sandboxlay.addStretch(209)
        self.sandbox.setLayout(self.sandboxlay)

        # self.sandbox.seth


        mainlay.addWidget(loadbox,1)
        mainlay.addWidget(self.sandbox,10)

        self.setMouseTracking(True)

    def start_process(self):
        modules = self.sandbox.gui_modules

        # m = (modules - list())[0]
        m = [m for m in modules if m not in map(lambda m: m.module.next_node, modules)][0]

        # m = m.next_node
        extras = m.module.run()
        v = ResultView(extras)
        v.exec_()


def main():
    app = QApplication(sys.argv)
    app.setStyle('Fusion')
    win = AfelApp()
    # win.showMaximized()
    win.show()
    app.exec_()

if __name__ == '__main__':
    sys.exit(main())
