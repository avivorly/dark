from PyQt5 import QtCore
from PyQt5.QtWidgets import QGridLayout, QDialog ,QPushButton, QScrollArea, QDesktopWidget, QLabel, QDialogButtonBox, QWidget, QVBoxLayout, QHBoxLayout, QLineEdit, QApplication, QSpinBox,QCheckBox,QFileDialog
from functools import partial


class ModuleForm(QDialog):
    def __init__(self, gui_modul, keys):
        self.gui_modul = gui_modul
        super().__init__()
        self.first = True
        self.initUI(keys)

    def open_file(self):
        if not self.first:
            self.file_path = QFileDialog.getOpenFileName(self)
            self.first = True
            self.path_line_edit.setText(self.file_path[0])
            self.save()
        self.first = False

    def initUI(self, keys):
        self.setMinimumSize(300, 100)
        lay = QGridLayout()
        self.setLayout(lay)
        row = 0
        inputs = []
        self.setts = {}
        for name, soog in keys:
            module_o = self.gui_modul.module.o
            lay.addWidget(QLabel(name),row,0)
            if soog == 'spin':
                w = QSpinBox()
                w.setRange(-2147483648, 2147483647)
                w.valueChanged.connect(self.save)

            if soog == 'str':
                w = QLineEdit()
                w.textChanged.connect(self.save)

            if soog == 'file':
                w = QLineEdit('open file')
                self.path_line_edit = w
                # print(dir(w))
                w.textChanged.connect(self.open_file)


            self.setts[name] = w
            inputs.append(w)
            lay.addWidget(w, row ,1)

            row = row + 1

            for name, w in self.setts.items():
                if name in module_o.keys():
                    method = 'setValue'
                    mdic = {
                        QCheckBox: 'setChecked',
                        QLineEdit: 'setText'
                    }
                    if type(w) in mdic.keys():
                        method = mdic[type(w)]
                    eval('w.{0}(module_o[name])'.format(method))
    def get_value_from_widget(self, w):
        method = 'value'
        mdic = {
            QCheckBox: 'isChecked',
            QLineEdit: 'text'
        }
        if type(w) in mdic.keys():
            method = mdic[type(w)]
        return eval('w.{0}()'.format(method))
    def save(self):
        print(self.setts)
        for k,v in self.setts.items():
            print(v)
            self.gui_modul.module.o[k] = self.get_value_from_widget(v)





        # self.setWindowTitle(f"{table.text()} invoice")
        #
        # self.setObjectName("Dialog")
        # self.setFixedSize(350, 450)
        # QtCore.QMetaObject.connectSlotsByName(self)

        # edit_table_name = QLineEdit()
        # edit_table_name.setText(table.text())
        # edit_table_name.setAlignment(QtCore.Qt.AlignRight);
        # edit_table_name.textChanged.connect(partial( self.change_table_text, table))

        # label_name = QLabel()
        # label_name.setText("modole:")
        # label_name.setMaximumSize(60,30)



        # title_box.addWidget(edit_table_name)
        # title_box.addWidget(label_name)

        # save_btn = QPushButton('save', self)
        # save_btn.clicked.connect(self.reject)
        #
        # pay_btn = QPushButton('number', self)
        # pay_btn.clicked.connect(self.accept)
        #
        # delete_btn = QPushButton('delete', self)
        # delete_btn.clicked.connect(self.reject)
        #
        # button_box = QHBoxLayout()
        # button_box.addWidget(save_btn)
        # button_box.addWidget(pay_btn)
        # button_box.addWidget(delete_btn)
        #
        # add_prod_btn = QPushButton('Add', self)
        # add_prod_btn.setMaximumSize(60,30)

        # header_box = QGridLayout()
        # label_item = QLabel("a")
        # label_quantity = QLabel(f"v")
        # label_price = QLabel(f"b")
        # btn_remove = QLabel("c")
        # header_box.addWidget(label_item, 0, 0)
        # header_box.addWidget(label_quantity, 0, 2)
        # header_box.addWidget(label_price, 0, 4)
        # header_box.addWidget(btn_remove, 0, 5)
        #
        # _widget = QWidget()
        # _widget.setMinimumSize(300,300)
        # g_box = QGridLayout(_widget)
        # i = 0
        # for item, quantity in table.products:
        #     label_item = QLabel(f"{item}")
        #
        #     label_price = QLabel(f"{quantity*7}")
        #
        #     le_quantity = QLineEdit()
        #     le_quantity.setText(f"{quantity}")
        #     le_quantity.setMaximumSize(20,20)
        #     le_quantity.setAlignment(QtCore.Qt.AlignHCenter);
        #     le_quantity.textEdited.connect(partial( self.change_quantity_text, item, quantity, le_quantity, label_price, table))
        #
        #
        #
        #     btn_minus = QPushButton("-")
        #     btn_minus.setMaximumSize(20,20)
        #     btn_minus.clicked.connect(partial( self.change_quantity, -1, item, table, le_quantity, label_price))
        #
        #     btn_plus = QPushButton("+")
        #     btn_plus.setMaximumSize(25,20)
        #     btn_plus.clicked.connect(partial( self.change_quantity, 1, item, table, le_quantity, label_price))
        #
        #     btn_remove = QPushButton("remove")
        #     btn_remove.clicked.connect(partial( self.delete_item, item, le_quantity, table, i, g_box))
        #
        #     g_box.addWidget(label_item, i, 0)
        #     g_box.addWidget(btn_minus, i, 1, QtCore.Qt.AlignRight)
        #     g_box.addWidget(le_quantity, i, 2, QtCore.Qt.AlignHCenter)
        #     g_box.addWidget(btn_plus, i, 3, QtCore.Qt.AlignLeft)
        #     g_box.addWidget(label_price, i, 4)
        #     g_box.addWidget(btn_remove, i, 5)
        #     i+=1

        # g_box.setAlignment(QtCore.Qt.AlignTop)
        #
        #
        # scroll_area = QScrollArea()
        # scroll_area.setWidget(_widget)
        # scroll_area.setFixedHeight(300)
        #
        # v_box = QVBoxLayout()
        # v_box.addLayout(title_box)
        # v_box.addLayout(header_box)
        # v_box.addWidget(scroll_area)
        # v_box.addWidget(add_prod_btn, QtCore.Qt.AlignLeft)
        # v_box.addStretch(1)
        # v_box.addLayout(button_box)
        # self.setLayout(v_box)

        self.animate_on_show()

    def animate_on_show(self):
        self.animation = QtCore.QPropertyAnimation(self, b"geometry")
        self.animation.setDuration(300) #Default 250ms
        screenShape = QDesktopWidget().screenGeometry()
        self.animation.setStartValue(QtCore.QRect(int(screenShape.width()/2)-150, -300, 0, 0))
        self.animation.setEndValue(QtCore.QRect(int(screenShape.width()/2) -150, 30, 0, 0))
        self.animation.start()
        self.setModal(True)

    def change_table_text(self, table, table_name):
        table.setText(table_name)

    def change_quantity_text(self, id, quantity, label_q, label_p, table, new_q):
        try:
            item = next((x for x in table.products if x[0]==id), None)
            # print(item)
            # print(new_q)
            if int(new_q) >= 1 and item is not None:
                item[1] = int(new_q)
                label_p.setText(f"{item[1] * 7}") # find price by product id
            else:
                item[1] = 1
                label_q.setText("1")
                label_p.setText(f"{1 * 7}")
        except:
            print("ex")
        self.show()
            # label_q.setText("1")
            # label_p.setText(f"{1 * 7}")


    def change_quantity(self, amount, id, table, label_q, label_p):
        index = table.products.index([id,int(label_q.text())])
        if table.products[index][1] + amount == 0:
            return
        table.products[index][1] += amount
        label_q.setText(f"{table.products[index][1]}")
        label_p.setText(f"{table.products[index][1] * 7}") # 7 refer to the product price which will be set when the data will be created
        print('complete')

    def delete_item(self, id, label_q, table, row, grid):
        index = table.products.index([id,int(label_q.text())])
        table.products.remove([id,int(label_q.text())])
        for col in range(grid.columnCount()):
            widget = grid.itemAtPosition(row, col).widget();
            grid.removeWidget(widget);
            widget.deleteLater()
        self.show()


    def closeEvent(self, e):
            super().closeEvent(e)
