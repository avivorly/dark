from PyQt5.QtWidgets import QPushButton
from PyQt5.QtCore import Qt, QSize
from PyQt5.QtGui import QIcon
import sys
from PyQt5.QtWidgets import QPushButton, QWidget, QApplication, QMainWindow, QHBoxLayout,QVBoxLayout, QGridLayout, QDialog
from PyQt5.QtCore import Qt, QSize
from PyQt5.QtGui import QIcon
import sys
import datetime
from moduleGUI import ModuleGui
from PyQt5.QtGui import QPainter, QBrush, QPen
import PyQt5.QtCore

from PyQt5.QtCore import Qt
from PyQt5 import QtGui

from PyQt5.QtWidgets import QApplication, QMainWindow

from PyQt5.QtWidgets import QFileDialog

# exec(open("/home/aviv/avivsroot/lib/aviv_root.py").read())
from PyQt5.QtWidgets import (QMessageBox)
from PyQt5.QtWidgets import QMainWindow, QAction
from PyQt5.QtWidgets import (QApplication, QCheckBox,
                             QGridLayout, QGroupBox, QHBoxLayout, QLabel, QLineEdit,
                             QPushButton, QSizePolicy,
                             QSpinBox, QTableWidget,
                             QVBoxLayout, QWidget)
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.backends.backend_qt5agg import NavigationToolbar2QT as NavigationToolbar


class SandBox(QGroupBox):
    def __init__(self):
        super().__init__()
        self.setStyleSheet("""
            .QWidget{
                border: 5px solid black;

                background-color: blue;
                /* background-image: url('./bg.jpg');*/
            }
        """)
        self.gui_modules = []
        self.paints = []
        # self.setStyleSheet("background-color:{0};".format('blue'))

    def add_module(self, loc, klass):
        m = ModuleGui(self, klass)
        m.resize(220, 220)

        x1, y1 = loc.x(), loc.y()
        r1, r2 = self.x(), self.y()
        m.move(x1 - r1, y1 - r2)

        # table.clicked.connect(partial(self.show_invoice, table, 1, 1))
        m.show()
        # self.ID += 1
        self.gui_modules.append(m)

    def update_connections(self):
        self.last = datetime.datetime.now()
        right_module_gui = None
        left_module_gui = None

        for m in self.gui_modules:
            if m.right.on:
                right_module_gui = m
            if m.left.on:
                left_module_gui = m
        if right_module_gui and left_module_gui and right_module_gui != left_module_gui:

            right_module_gui.module.next_node = left_module_gui.module
            self.paints.append([right_module_gui.x(),right_module_gui.y(),left_module_gui.x(),left_module_gui.y()])
            for m in self.gui_modules:
                m.reset_on_of()

    def paintEvent(self, *args, **kwargs):

        # print(datetime.datetime.now())
        # if datetime.datetime.now().timestamp() - self.last.timestamp() < 10:
        for gm in self.gui_modules:
            if gm.module.next_node:
                next_gm = gm.module.next_node.gui
                if next_gm:
                    qp = QPainter()
                    qp.begin(self)
                    qp.drawLine(gm.x()+ 120, gm.y()+ 120, next_gm.x()+120, next_gm.y()+ 120)
                    self.update()





        super().paintEvent(*args, **kwargs)