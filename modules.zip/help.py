while(True):
                str = input()
                if str == 'e':
                    break
                else:
                    print(eval(str))

