import os, sys, re
import datetime
import numpy as np
from numpy import exp
from astropy.io import fits
from matplotlib.figure import Figure
# import ROOT
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.backends.backend_qt5agg import NavigationToolbar2QT as NavigationToolbar

class Module():
    def __init__(self):
        super().__init__()
        if not hasattr(self,'o'):
            print('done zerrr')
            self.o = {}
        self.next_node = None

    def run(self):
        data, views = self.process()
        extras = [{
            'name': self.__class__.__name__,
            'data': data,
            'views': views
        }]

        if self.next_node:
            self.next_node.data = data
            next_extras = self.next_node.run()
            extras += next_extras
        print('I just finis my.{0}'.format(self.__class__.__name__))
        return extras

    @classmethod
    def open_file(cls, path, CONST_nonReal = 20):
        m = fits.open(path)[0].data
        rows = len(m)
        cols = len(m[0])

        m = np.delete(m, np.s_[0:CONST_nonReal], axis=0)
        m = np.delete(m, np.s_[0:CONST_nonReal], axis=1)
        m = np.delete(m, np.s_[rows - CONST_nonReal:rows], axis=0)
        m = np.delete(m, np.s_[cols - CONST_nonReal:cols], axis=1)
        return m

    @classmethod
    def mask(cls, mat, mask):
        mat = mat.copy()
        rowsLen = len(mat)
        colsLen = len(mat[0])
        for i in range(0, rowsLen):
            for j in range(0, colsLen):
                if mask[i][j] - 32 not in [0, 1, 2, 3]:
                    mat[i][j] = np.NAN
        # print('now')
        # print(mat)
        return mat

    @classmethod
    def rows_of(cls, mat):
        return mat

    @classmethod
    def columns_of(cls, mat):
        print('columns of?')
        colsLen = len(mat[0])
        rows = []
        for i in range(0, colsLen):

            # print(i)
            # print(mat)
            # print(mat[:, i])
            rows.append(mat[:, i])
            # try:
            #
            #
            # except:
            #     print('print')
            #     print(rows)
            #     print(i)
            #     while (True):
            #         str = input()
            #         if str == 'e':
            #             break
            #         else:
            #             print(eval(str))


        return rows

