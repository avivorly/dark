from modules.Module import Module

class One(Module):
    keys = [
    ]

    def process(self):
        views = [
            ['start with 1', 'string', 'told you, i am one']
        ]

        data = 1

        return data, views