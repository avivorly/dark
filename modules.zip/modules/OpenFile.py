from modules.Module import Module
import numpy as np
class OpenFile(Module):
    keys = [
        ['path', 'file']
    ]
    def __init__(self):
        super().__init__()
        self.o['path'] = 'may23/proc_skp_2hr_vddOFF_14_12.fits'

    def process(self):
        views = []
        data =  self.open_file(self.o['path'])

        return data, views