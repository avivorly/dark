from modules.Module import Module

class AddNum(Module):
    keys = [
        ['number', 'spin']
    ]
    o = {'number': 1}

    def process(self):
        data = self.data + self.o['number']

        views = [
            ['final result', 'number', data]
        ]

        return data, views

